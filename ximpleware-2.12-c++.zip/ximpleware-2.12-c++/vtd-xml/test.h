#ifndef TEST_H
#define TEST_H
using namespace com_ximpleware;
namespace abc1 {
	class t1{
		friend class VTDNav;
	public:
		int t2;
	};

	int i;
#define try_good printf("11111\n");
	void f1(){};
	void f2(){};
}


#endif